import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert, KeyboardAvoidingView, Platform, Pressable, SafeAreaView, ScrollView,
  StyleSheet, Text, TextInput, View
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';
import { StatusBar } from 'expo-status-bar';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

const STORAGE = '@astracare_data_v1';

const DEFAULT_CAR = {
  name: 'Meu Astra', modelYear: '2009/2010', version: 'Astra Sedan 2.0 8V Flex',
  transmission: 'Manual — 5 marchas', currentKm: 0, plate: '', chassis: '',
  engine: 'GM Família II — 2.0 8V FlexPower', displacement: '1.998 cm³',
  fuel: 'Etanol / Gasolina', power: '140 cv (etanol) / 133 cv (gasolina)',
  torque: '19,7 kgfm (etanol) / 18,9 kgfm (gasolina)', compression: '11,5:1',
  cylinders: '4 em linha', valves: '8 — 2 por cilindro', maxRPM: '6.400 rpm', drive: 'Dianteira',
  dimensions: '4.342 × 1.709 × 1.425 mm; entre-eixos 2.614 mm', weight: '1.190 kg',
  trunk: '460 L', tank: '52 L', tires: '205/55 R16',
  suspension: 'Dianteira McPherson; traseira eixo de torção',
  brakes: 'Disco ventilado dianteiro; tambor traseiro', steering: 'Hidráulica',
  consumption: 'Gasolina: 8,6 km/l cidade; 11,5 km/l estrada. Etanol: 6,1 km/l cidade; 8,2 km/l estrada'
};

const DEFAULT_MAINTENANCE = [
  { id:'oil', item:'Óleo do motor', category:'Motor', intervalKm:10000, intervalMonths:12, lastKm:0, lastDate:'', notes:'10.000 km ou 12 meses em uso normal; 5.000 km ou 6 meses em uso severo.' },
  { id:'oilfilter', item:'Filtro de óleo', category:'Motor', intervalKm:20000, intervalMonths:null, lastKm:0, lastDate:'', notes:'Primeira troca junto com o primeiro óleo; depois a cada duas trocas de óleo.' },
  { id:'timing', item:'Correia dentada', category:'Motor', intervalKm:50000, intervalMonths:null, lastKm:0, lastDate:'', notes:'Controle conforme plano de manutenção; verificar estado e tensionador nas revisões.' },
  { id:'spark', item:'Velas de ignição', category:'Motor', intervalKm:30000, intervalMonths:null, lastKm:0, lastDate:'', notes:'Troca conforme plano de revisão.' },
  { id:'air', item:'Filtro de ar do motor', category:'Filtros', intervalKm:30000, intervalMonths:null, lastKm:0, lastDate:'', notes:'30.000 km em condições normais; antecipar em poeira/terra.' },
  { id:'fuel', item:'Filtro de combustível', category:'Filtros', intervalKm:10000, intervalMonths:null, lastKm:0, lastDate:'', notes:'Lembrete de revisão; confirme a aplicação no seu plano específico.' },
  { id:'brakefluid', item:'Fluido de freio/embreagem', category:'Freios', intervalKm:30000, intervalMonths:24, lastKm:0, lastDate:'', notes:'30.000 km ou 2 anos, o que ocorrer primeiro.' },
  { id:'coolant', item:'Líquido de arrefecimento', category:'Fluidos', intervalKm:150000, intervalMonths:60, lastKm:0, lastDate:'', notes:'150.000 km ou 5 anos.' },
  { id:'cabin', item:'Filtro do ar-condicionado', category:'Ar-condicionado', intervalKm:10000, intervalMonths:null, lastKm:0, lastDate:'', notes:'Lembrete de inspeção/troca; confirmar se o veículo possui o elemento e a aplicação.' },
  { id:'wipers', item:'Palhetas do limpador', category:'Carroceria', intervalKm:null, intervalMonths:12, lastKm:0, lastDate:'', notes:'Controle principalmente por condição.' },
  { id:'tires', item:'Pneus', category:'Segurança', intervalKm:10000, intervalMonths:null, lastKm:0, lastDate:'', notes:'Inspecionar pressão, desgaste, danos e torque das rodas.' }
];

const BRL = n => Number(n || 0).toLocaleString('pt-BR', { style:'currency', currency:'BRL' });
const fmtKm = n => Number(n || 0).toLocaleString('pt-BR') + ' km';
const daysFromNow = d => Math.ceil((new Date(d) - new Date()) / 86400000);

export default function App() {
  const [data, setData] = useState({ car: DEFAULT_CAR, maintenance: DEFAULT_MAINTENANCE, history: [], fuelings: [] });
  const [loaded, setLoaded] = useState(false);
  const [tab, setTab] = useState('home');
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE);
        if (raw) setData(JSON.parse(raw));
      } finally { setLoaded(true); }
    })();
  }, []);

  useEffect(() => { if (loaded) AsyncStorage.setItem(STORAGE, JSON.stringify(data)); }, [data, loaded]);

  useEffect(() => {
    Notifications.requestPermissionsAsync().catch(() => {});
  }, []);

  const alerts = useMemo(() => data.maintenance.filter(m => m.intervalKm && (m.lastKm + m.intervalKm - Number(data.car.currentKm)) <= 1000), [data]);

  const updateCar = patch => setData(d => ({ ...d, car: { ...d.car, ...patch }}));

  const registerMaintenance = (id, km, date, note) => {
    const value = Number(String(km).replace(/\D/g,'')) || Number(data.car.currentKm);
    setData(d => ({
      ...d,
      car: { ...d.car, currentKm: Math.max(Number(d.car.currentKm), value) },
      maintenance: d.maintenance.map(m => m.id === id ? { ...m, lastKm:value, lastDate:date, notes:note || m.notes } : m),
      history: [{ id:Date.now().toString(), item:d.maintenance.find(m=>m.id===id)?.item || 'Manutenção', km:value, date, note:note || '' }, ...d.history]
    }));
    setSelected(null);
  };

  if (!loaded) return <SafeAreaView style={styles.center}><Text>Carregando AstraCare…</Text></SafeAreaView>;

  return <SafeAreaView style={styles.safe}>
    <StatusBar style="auto" />
    <View style={styles.header}><Text style={styles.brand}>ASTRA CARE</Text><Text style={styles.subtitle}>Diário de manutenção</Text></View>
    {tab === 'home' && <Home data={data} alerts={alerts} setTab={setTab} onSelect={setSelected} />}
    {tab === 'maintenance' && <Maintenance data={data} onSelect={setSelected} />}
    {tab === 'history' && <History data={data} />}
    {tab === 'specs' && <Specs car={data.car} />}
    {tab === 'car' && <CarForm car={data.car} updateCar={updateCar} />}
    <Nav tab={tab} setTab={setTab} />
    {selected && <MaintenanceModal item={selected} car={data.car} onClose={()=>setSelected(null)} onSave={registerMaintenance} />}
  </SafeAreaView>;
}

function Home({data, alerts, setTab, onSelect}) {
  return <ScrollView contentContainerStyle={styles.content}>
    <View style={styles.hero}>
      <Text style={styles.heroTitle}>{data.car.version}</Text>
      <Text style={styles.muted}>{data.car.modelYear}</Text>
      <Text style={styles.km}>{fmtKm(data.car.currentKm)}</Text>
      <Text style={styles.muted}>Quilometragem atual</Text>
    </View>
    <View style={styles.row}>
      <Card title="Pendências" value={String(alerts.length)} icon="⚠️" />
      <Card title="Histórico" value={String(data.history.length)} icon="🔧" />
    </View>
    <SectionTitle title="Próximas manutenções" />
    {data.maintenance.slice(0,6).map(m => <MaintenanceCard key={m.id} m={m} currentKm={data.car.currentKm} onPress={()=>onSelect(m)} />)}
    <Pressable style={styles.primary} onPress={()=>setTab('maintenance')}><Text style={styles.primaryText}>Ver todas as manutenções</Text></Pressable>
  </ScrollView>;
}

function Maintenance({data,onSelect}) { return <ScrollView contentContainerStyle={styles.content}>
  <SectionTitle title="Plano de manutenção" />
  {data.maintenance.map(m=><MaintenanceCard key={m.id} m={m} currentKm={data.car.currentKm} onPress={()=>onSelect(m)} />)}
</ScrollView>; }

function MaintenanceCard({m,currentKm,onPress}) {
  const next = m.intervalKm ? m.lastKm + m.intervalKm : null;
  const remaining = next == null ? null : next - Number(currentKm);
  const urgent = remaining != null && remaining <= 1000;
  return <Pressable style={[styles.maintenanceCard, urgent && styles.urgent]} onPress={onPress}>
    <View style={{flex:1}}><Text style={styles.cardTitle}>{m.item}</Text><Text style={styles.muted}>{m.category}</Text></View>
    <View style={{alignItems:'flex-end'}}>{next != null ? <><Text style={[styles.remaining, urgent && styles.red]}>{remaining <= 0 ? 'VENCIDA' : fmtKm(remaining)}</Text><Text style={styles.muted}>próxima {fmtKm(next)}</Text></> : <Text style={styles.muted}>por inspeção/data</Text>}</View>
  </Pressable>;
}

function MaintenanceModal({item,car,onClose,onSave}) {
  const [km,setKm]=useState(String(car.currentKm)); const [date,setDate]=useState(new Date().toISOString().slice(0,10)); const [note,setNote]=useState('');
  return <View style={styles.overlay}><KeyboardAvoidingView behavior={Platform.OS==='ios'?'padding':undefined} style={styles.modal}><Text style={styles.modalTitle}>{item.item}</Text>
    <Text style={styles.label}>Quilometragem do serviço</Text><TextInput style={styles.input} value={km} onChangeText={setKm} keyboardType="numeric" />
    <Text style={styles.label}>Data</Text><TextInput style={styles.input} value={date} onChangeText={setDate} placeholder="AAAA-MM-DD" />
    <Text style={styles.label}>Observação</Text><TextInput style={[styles.input,{height:80}]} value={note} onChangeText={setNote} multiline />
    <Text style={styles.help}>{item.notes}</Text>
    <View style={styles.row}><Pressable style={styles.secondary} onPress={onClose}><Text>Cancelar</Text></Pressable><Pressable style={styles.primarySmall} onPress={()=>onSave(item.id,km,date,note)}><Text style={styles.primaryText}>Salvar</Text></Pressable></View>
  </KeyboardAvoidingView></View>;
}

function History({data}) { return <ScrollView contentContainerStyle={styles.content}><SectionTitle title="Histórico de serviços" />{data.history.length===0?<Text style={styles.muted}>Nenhuma manutenção registrada ainda.</Text>:data.history.map(h=><View style={styles.history} key={h.id}><Text style={styles.cardTitle}>{h.item}</Text><Text>{fmtKm(h.km)} • {h.date}</Text>{h.note?<Text style={styles.muted}>{h.note}</Text>:null}</View>)}</ScrollView>; }

function Specs({car}) { const groups=[['Identificação',[['Modelo',car.version],['Ano',car.modelYear],['Combustível',car.fuel],['Câmbio',car.transmission],['Tração',car.drive]]],['Motor',[['Motor',car.engine],['Cilindrada',car.displacement],['Potência',car.power],['Torque',car.torque],['Compressão',car.compression],['Cilindros',car.cylinders],['Válvulas',car.valves],['Rotação máxima',car.maxRPM]]],['Dimensões e capacidades',[['Dimensões',car.dimensions],['Peso',car.weight],['Porta-malas',car.trunk],['Tanque',car.tank]]],['Chassi',[['Pneus',car.tires],['Suspensão',car.suspension],['Freios',car.brakes],['Direção',car.steering]]],['Consumo de referência',[['Consumo',car.consumption]]]]; return <ScrollView contentContainerStyle={styles.content}>{groups.map(([title,rows])=><View key={title}><SectionTitle title={title}/><View style={styles.panel}>{rows.map(([a,b])=><View style={styles.spec} key={a}><Text style={styles.muted}>{a}</Text><Text>{b}</Text></View>)}</View></View>)}<Text style={styles.help}>Dados técnicos de referência para o Astra Sedan 2.0 8V Flex 2009/2010. Confirme itens específicos pela versão/chassi e manual do veículo.</Text></ScrollView>; }

function CarForm({car,updateCar}) { const [km,setKm]=useState(String(car.currentKm)); return <ScrollView contentContainerStyle={styles.content}><SectionTitle title="Meu veículo"/><View style={styles.panel}>
  <Field label="Nome" value={car.name} onChangeText={v=>updateCar({name:v})}/><Field label="Versão" value={car.version} onChangeText={v=>updateCar({version:v})}/><Field label="Quilometragem atual" value={km} keyboardType="numeric" onChangeText={v=>{setKm(v);updateCar({currentKm:Number(v.replace(/\D/g,''))||0})}}/><Field label="Placa" value={car.plate} onChangeText={v=>updateCar({plate:v.toUpperCase()})}/><Field label="Chassi" value={car.chassis} onChangeText={v=>updateCar({chassis:v.toUpperCase()})}/>
  <Text style={styles.label}>Câmbio</Text><Pressable style={styles.select} onPress={()=>updateCar({transmission:car.transmission.includes('Manual')?'Automático — 4 marchas':'Manual — 5 marchas'})}><Text>{car.transmission}</Text></Pressable>
  </View><Text style={styles.help}>Os dados ficam salvos localmente no iPhone neste primeiro projeto.</Text></ScrollView>; }

function Field({label,value,onChangeText,keyboardType}) { return <View><Text style={styles.label}>{label}</Text><TextInput style={styles.input} value={value} onChangeText={onChangeText} keyboardType={keyboardType}/></View>; }
function Card({title,value,icon}) { return <View style={styles.stat}><Text>{icon}</Text><Text style={styles.statValue}>{value}</Text><Text style={styles.muted}>{title}</Text></View>; }
function SectionTitle({title}) { return <Text style={styles.sectionTitle}>{title}</Text>; }
function Nav({tab,setTab}) { const items=[['home','🏠','Início'],['maintenance','🔧','Manutenção'],['history','📋','Histórico'],['specs','📖','Ficha'],['car','🚗','Carro']]; return <View style={styles.nav}>{items.map(([id,icon,label])=><Pressable key={id} onPress={()=>setTab(id)} style={styles.navItem}><Text style={{fontSize:21}}>{icon}</Text><Text style={[styles.navText,tab===id&&styles.navActive]}>{label}</Text></Pressable>)}</View>; }

const styles=StyleSheet.create({
 safe:{flex:1,backgroundColor:'#f5f6f8'}, center:{flex:1,alignItems:'center',justifyContent:'center'}, header:{paddingHorizontal:20,paddingTop:8,paddingBottom:10,backgroundColor:'#fff'},brand:{fontSize:24,fontWeight:'900',letterSpacing:1},subtitle:{color:'#6b7280'},content:{padding:16,paddingBottom:100},hero:{backgroundColor:'#fff',borderRadius:18,padding:20,marginBottom:12},heroTitle:{fontSize:21,fontWeight:'800'},km:{fontSize:32,fontWeight:'900',marginTop:18},muted:{color:'#6b7280',fontSize:13},row:{flexDirection:'row',gap:10},stat:{backgroundColor:'#fff',borderRadius:16,padding:14,flex:1},statValue:{fontSize:25,fontWeight:'800',marginVertical:3},sectionTitle:{fontSize:19,fontWeight:'800',marginTop:18,marginBottom:10},maintenanceCard:{backgroundColor:'#fff',borderRadius:15,padding:15,marginBottom:9,flexDirection:'row',alignItems:'center'},urgent:{borderWidth:1,borderColor:'#f2b8b5'},cardTitle:{fontWeight:'700',fontSize:16,marginBottom:3},remaining:{fontWeight:'800'},red:{color:'#c62828'},primary:{backgroundColor:'#111827',borderRadius:14,padding:15,alignItems:'center',marginTop:8},primaryText:{color:'#fff',fontWeight:'800'},primarySmall:{backgroundColor:'#111827',borderRadius:12,padding:13,paddingHorizontal:22},secondary:{backgroundColor:'#e5e7eb',borderRadius:12,padding:13,paddingHorizontal:22,marginRight:8},overlay:{position:'absolute',inset:0,backgroundColor:'rgba(0,0,0,.45)',justifyContent:'flex-end',zIndex:20},modal:{backgroundColor:'#fff',borderTopLeftRadius:24,borderTopRightRadius:24,padding:20,paddingBottom:30},modalTitle:{fontSize:22,fontWeight:'900',marginBottom:16},label:{fontSize:12,color:'#6b7280',marginTop:10,marginBottom:5},input:{backgroundColor:'#f3f4f6',borderRadius:10,padding:12,fontSize:16},help:{color:'#6b7280',fontSize:12,marginTop:12,lineHeight:18},history:{backgroundColor:'#fff',padding:15,borderRadius:14,marginBottom:9},panel:{backgroundColor:'#fff',borderRadius:15,padding:15},spec:{paddingVertical:9,borderBottomWidth:1,borderBottomColor:'#eee'},select:{backgroundColor:'#f3f4f6',borderRadius:10,padding:13},nav:{position:'absolute',bottom:0,left:0,right:0,height:72,backgroundColor:'#fff',borderTopWidth:1,borderTopColor:'#e5e7eb',flexDirection:'row',justifyContent:'space-around',alignItems:'center'},navItem:{alignItems:'center',minWidth:58},navText:{fontSize:11,color:'#6b7280',marginTop:2},navActive:{color:'#111827',fontWeight:'800'}
});
