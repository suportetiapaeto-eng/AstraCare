# AstraCare — versão Expo / React Native

Esta versão substitui o projeto SwiftUI por React Native + Expo para permitir teste no iPhone usando o Expo Go, inclusive a partir de um PC Windows.

## 1. Instalar no Windows

Instale o Node.js LTS:
https://nodejs.org/

Depois abra o PowerShell nesta pasta e execute:

```powershell
npm install
npx expo start
```

Será mostrado um QR Code no terminal/navegador.

## 2. Abrir no iPhone

1. Instale **Expo Go** pela App Store.
2. Deixe o iPhone e o computador na mesma rede Wi-Fi.
3. Abra o Expo Go.
4. Escaneie o QR Code exibido pelo `npx expo start`.
5. O AstraCare abrirá no iPhone.

Se a rede não permitir conexão direta, use:

```powershell
npx expo start --tunnel
```

## 3. O que esta versão já possui

- Dashboard do Astra.
- Quilometragem atual.
- Plano de manutenção.
- Cálculo da próxima manutenção por km.
- Registro de manutenção.
- Histórico.
- Ficha técnica do Astra Sedan 2.0 8V Flex 2009/2010.
- Placa e chassi.
- Dados persistidos localmente com AsyncStorage.
- Preparação para notificações do iPhone.

## 4. Próxima etapa

Para transformar em aplicativo próprio instalado no iPhone (sem depender do Expo Go), podemos usar EAS Build e gerar um build iOS. Para distribuição na App Store, é necessário uma conta Apple Developer.

## Observação sobre dados do veículo

Os dados técnicos são referências da versão Astra Sedan 2.0 8V Flex 2009/2010. Equipamentos e especificações podem variar conforme versão/chassi. Os intervalos de manutenção devem ser conferidos no manual específico do veículo.
